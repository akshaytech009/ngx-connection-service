import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
export declare class ConnectionServiceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConnectionServiceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConnectionServiceModule, never, [typeof i1.HttpClientModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConnectionServiceModule>;
}
