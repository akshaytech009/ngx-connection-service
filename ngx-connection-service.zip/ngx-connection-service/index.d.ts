/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-connection-service" />
export * from './public_api';
